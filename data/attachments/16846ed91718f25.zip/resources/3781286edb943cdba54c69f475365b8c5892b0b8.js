import{u as r}from"./4b4bc88f.C26USmk8.js";import{P as o}from"./164ad2e3.DZSd7pLX.js";function s(){return r(o)}export{s as u};
