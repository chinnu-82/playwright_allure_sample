import{s as o,u as r}from"./2c1ab0fe.YffFoKfv.js";const a=o(function(o,a){const{allow:s,...t}=o;return r("iframe",{...t,ref:a,allow:s})});export{a as I};
