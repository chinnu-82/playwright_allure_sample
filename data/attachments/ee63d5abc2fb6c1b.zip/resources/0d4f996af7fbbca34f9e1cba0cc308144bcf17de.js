import{u as r}from"./4b4bc88f.BBKD75Do.js";import{P as o}from"./164ad2e3.BR4HwLPK.js";function s(){return r(o)}export{s as u};
