function e(e){return Boolean(e.analyticsProcessingAllowed||e.marketingAllowed)}export{e as h};
