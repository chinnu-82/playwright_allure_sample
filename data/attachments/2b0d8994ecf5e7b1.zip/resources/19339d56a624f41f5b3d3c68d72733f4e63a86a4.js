import{D as o,u as r}from"./2c1ab0fe.Bf8FS-kA.js";const t=o(function(o,t){const{allow:a,...e}=o;return r("iframe",{...e,ref:t,allow:a})});export{t as I};
