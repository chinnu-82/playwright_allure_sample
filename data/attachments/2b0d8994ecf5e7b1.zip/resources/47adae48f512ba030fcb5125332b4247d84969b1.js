import{u as r}from"./4b4bc88f.C6QXxWcp.js";import{P as o}from"./164ad2e3.BPEX42uv.js";function s(){return r(o)}export{s as u};
