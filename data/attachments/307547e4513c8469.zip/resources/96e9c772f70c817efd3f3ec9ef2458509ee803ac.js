const s=s=>""===s?"":`${s.charAt(0).toLocaleUpperCase()+s.substring(1)}`;export{s as c};
