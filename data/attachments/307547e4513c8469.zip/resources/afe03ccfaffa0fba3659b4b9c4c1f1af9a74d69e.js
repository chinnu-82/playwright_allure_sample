import{u as r}from"./f67abd2c.DYpmk7mw.js";import{P as o}from"./164ad2e3.hrg71Gqs.js";function a(){return r(o)}export{a as u};
