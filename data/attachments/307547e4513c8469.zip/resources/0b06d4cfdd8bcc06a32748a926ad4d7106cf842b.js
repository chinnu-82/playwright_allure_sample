function e(e){return"SUBSCRIPTION"===e?"subscription":"oneTimePurchase"}export{e as m};
