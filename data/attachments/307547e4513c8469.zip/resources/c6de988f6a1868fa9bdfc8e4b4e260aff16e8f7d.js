function n(n){const e=n.session.paymentMethodOption.value;return null==e?"SHOP_PAY":e.name}export{n as g};
