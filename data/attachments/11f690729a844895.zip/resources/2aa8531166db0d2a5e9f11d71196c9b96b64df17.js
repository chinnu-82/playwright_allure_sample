import{u as r}from"./3d539943.Bqxdy1jJ.js";import{P as o}from"./164ad2e3.DsztAnP_.js";function s(){return r(o)}export{s as u};
