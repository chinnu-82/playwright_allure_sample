import{u as r}from"./4b4bc88f.DkycdxSK.js";import{P as o}from"./164ad2e3.DcJn775M.js";function s(){return r(o)}export{s as u};
