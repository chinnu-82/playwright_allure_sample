import{u as r}from"./3d539943.Bb9plxmS.js";import{P as o}from"./164ad2e3.CmoHQefk.js";function s(){return r(o)}export{s as u};
